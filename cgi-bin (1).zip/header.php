<?php
// header.php - Common header for all pages
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0, user-scalable=yes">
    <title><?php echo $pageTitle ?? 'Isaaq Kingdom'; ?> · Royal Heritage</title>
    <!-- Font Awesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;800;900&family=Plus+Jakarta+Sans:wght@300;400;600;700;800&display=swap" rel="stylesheet">
    <style>
        /* ===== GLOBAL RESET & VARIABLES ===== */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: #f2efe7;
            color: #1e2c2a;
            overflow-x: hidden;
            width: 100%;
        }

        :root {
            --sapphire: #0f4c5c;
            --ruby: #c44536;
            --amber: #ed9a4a;
            --cream: #fef9ed;
            --ivory: #fffcf0;
            --charcoal: #2d3e40;
            --gold-leaf: #dba870;
            --shadow-strong: 0 30px 40px -20px #0b3b3b;
        }

        /* ===== MOBILE FIRST APPROACH ===== */
        html {
            font-size: 14px;
        }

        /* ===== HERO SLIDESHOW ===== */
        .hero-slideshow {
            position: relative;
            height: 80vh;
            min-height: 500px;
            color: white;
            overflow: hidden;
            border-bottom: 6px solid var(--ruby);
        }

        @media (min-width: 768px) {
            .hero-slideshow {
                height: 92vh;
                min-height: 650px;
            }
        }

        .slides-container {
            width: 100%;
            height: 100%;
            position: relative;
        }

        .slide {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-size: cover;
            background-position: center 30%;
            opacity: 0;
            transition: opacity 1s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            z-index: 1;
        }

        .slide.active-slide {
            opacity: 1;
            z-index: 10;
        }

        .slide::before {
            content: "";
            position: absolute;
            inset: 0;
            background: linear-gradient(135deg, #00000080 0%, #0f4c5cb3 100%);
            z-index: 1;
        }

        .slide-content {
            position: relative;
            z-index: 20;
            max-width: 100%;
            padding: 1rem;
            transform: translateY(0);
            animation: riseUp 0.8s forwards;
            opacity: 0;
            width: 100%;
        }

        @media (min-width: 768px) {
            .slide-content {
                max-width: 1000px;
                padding: 2rem;
            }
        }

        .active-slide .slide-content {
            opacity: 1;
        }

        @keyframes riseUp {
            to { transform: translateY(0); opacity: 1; }
        }

        .slide-content h2 {
            font-family: 'Playfair Display', serif;
            font-size: 2.2rem;
            font-weight: 900;
            line-height: 1.2;
            text-shadow: 0 5px 15px #021010;
            letter-spacing: -0.5px;
            margin-bottom: 0.5rem;
        }

        @media (min-width: 480px) {
            .slide-content h2 {
                font-size: 3rem;
            }
        }

        @media (min-width: 768px) {
            .slide-content h2 {
                font-size: 4.5rem;
            }
        }

        .slide-content h2 i {
            color: var(--amber);
            margin-right: 10px;
            font-size: 2rem;
            filter: drop-shadow(0 0 10px #ffc27a);
            display: inline-block;
        }

        @media (min-width: 768px) {
            .slide-content h2 i {
                font-size: 4rem;
                margin-right: 20px;
            }
        }

        .slide-tagline {
            font-size: 1.1rem;
            font-weight: 500;
            background: rgba(196, 69, 54, 0.8);
            backdrop-filter: blur(8px);
            display: inline-block;
            padding: 0.4rem 1.2rem;
            border-radius: 50px;
            margin: 0.8rem 0;
            border: 1px solid var(--amber);
            font-weight: 600;
            word-break: break-word;
        }

        @media (min-width: 480px) {
            .slide-tagline {
                font-size: 1.3rem;
                padding: 0.5rem 1.8rem;
            }
        }

        @media (min-width: 768px) {
            .slide-tagline {
                font-size: 1.8rem;
                padding: 0.5rem 2.5rem;
                margin: 1.5rem 0;
            }
        }

        .slide-desc {
            font-size: 0.95rem;
            max-width: 90%;
            margin: 0.8rem auto;
            background: #0f4c5cb3;
            backdrop-filter: blur(8px);
            padding: 0.8rem 1.2rem;
            border-radius: 50px;
            border-left: 4px solid var(--amber);
            line-height: 1.4;
        }

        @media (min-width: 480px) {
            .slide-desc {
                font-size: 1.1rem;
                max-width: 80%;
                padding: 0.8rem 1.5rem;
            }
        }

        @media (min-width: 768px) {
            .slide-desc {
                font-size: 1.3rem;
                max-width: 700px;
                padding: 1rem 2rem;
                border-left-width: 6px;
            }
        }

        .slide-arrow {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            z-index: 50;
            background: rgba(255, 255, 255, 0.2);
            backdrop-filter: blur(8px);
            border: 1px solid rgba(255,215,140,0.6);
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: white;
            cursor: pointer;
            transition: 0.3s;
        }

        @media (min-width: 768px) {
            .slide-arrow {
                width: 60px;
                height: 60px;
                font-size: 2.5rem;
                border-width: 2px;
            }
        }

        .slide-arrow:hover {
            background: var(--ruby);
            border-color: white;
        }

        .prev { left: 10px; }
        .next { right: 10px; }

        @media (min-width: 768px) {
            .prev { left: 30px; }
            .next { right: 30px; }
        }

        .slide-indicators {
            position: absolute;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
            z-index: 50;
            display: flex;
            gap: 0.8rem;
        }

        @media (min-width: 768px) {
            .slide-indicators {
                bottom: 35px;
                gap: 1.2rem;
            }
        }

        .dot {
            width: 10px;
            height: 10px;
            background: rgba(255,255,240,0.5);
            border-radius: 50%;
            cursor: pointer;
            transition: 0.2s;
            border: 1px solid transparent;
        }

        @media (min-width: 768px) {
            .dot {
                width: 16px;
                height: 16px;
                border-width: 2px;
            }
        }

        .dot.active-dot {
            background: var(--amber);
            transform: scale(1.2);
            border-color: white;
        }

        /* ===== FLOATING NAVIGATION ===== */
        .floating-nav {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 0.5rem;
            padding: 0.8rem 1rem;
            background: #ffffffdd;
            backdrop-filter: blur(16px);
            border-radius: 40px;
            width: 95%;
            margin: -2rem auto 2rem;
            position: relative;
            z-index: 100;
            box-shadow: 0 15px 30px -15px #0f4c5c;
            border: 1px solid var(--amber);
        }

        @media (min-width: 480px) {
            .floating-nav {
                gap: 1rem;
                padding: 1rem 1.5rem;
                width: 90%;
            }
        }

        @media (min-width: 768px) {
            .floating-nav {
                gap: 2rem;
                padding: 1.2rem 2rem;
                border-radius: 100px;
                width: fit-content;
                margin: -3rem auto 3rem;
                border-width: 2px;
            }
        }

        .floating-nav a {
            text-decoration: none;
            font-weight: 700;
            font-size: 0.9rem;
            color: var(--sapphire);
            padding: 0.4rem 0.8rem;
            border-radius: 40px;
            transition: 0.2s;
            white-space: nowrap;
        }

        @media (min-width: 480px) {
            .floating-nav a {
                font-size: 1rem;
                padding: 0.5rem 1rem;
            }
        }

        @media (min-width: 768px) {
            .floating-nav a {
                font-size: 1.2rem;
                padding: 0.6rem 1.2rem;
            }
        }

        .floating-nav a:hover {
            background: var(--ruby);
            color: white;
        }

        .floating-nav a.active {
            background: var(--ruby);
            color: white;
        }

        .floating-nav a.admin-link {
            background: var(--ruby);
            color: white;
        }

        /* ===== CONTAINER & SECTIONS ===== */
        .container {
            width: 100%;
            max-width: 1300px;
            margin: 0 auto;
            padding: 0 1rem;
        }

        @media (min-width: 768px) {
            .container {
                padding: 0 2rem;
            }
        }

        .section-title {
            font-family: 'Playfair Display', serif;
            font-size: 2rem;
            font-weight: 800;
            color: var(--sapphire);
            margin: 2rem 0 1.5rem;
            position: relative;
            display: inline-block;
            line-height: 1.2;
        }

        @media (min-width: 480px) {
            .section-title {
                font-size: 2.5rem;
            }
        }

        @media (min-width: 768px) {
            .section-title {
                font-size: 3.2rem;
                margin: 2.5rem 0 2rem;
            }
        }

        .section-title::after {
            content: '';
            position: absolute;
            bottom: -8px;
            left: 0;
            width: 70%;
            height: 5px;
            background: linear-gradient(90deg, var(--ruby), var(--amber));
            border-radius: 10px;
        }

        @media (min-width: 768px) {
            .section-title::after {
                bottom: -10px;
                width: 80%;
                height: 8px;
            }
        }

        .title-icon {
            color: var(--ruby);
            margin-right: 0.8rem;
            font-size: 2rem;
        }

        @media (min-width: 768px) {
            .title-icon {
                font-size: 3rem;
            }
        }

        /* ===== PAGE HEADER ===== */
        .page-header {
            background: linear-gradient(135deg, var(--sapphire), #1a6a7a);
            color: white;
            padding: 3rem 1rem;
            text-align: center;
            margin-bottom: 2rem;
            border-radius: 0 0 60px 60px;
        }

        .page-header h1 {
            font-family: 'Playfair Display', serif;
            font-size: 2.5rem;
            margin-bottom: 1rem;
        }

        .page-header p {
            font-size: 1.2rem;
            max-width: 800px;
            margin: 0 auto;
        }

        /* ===== KING SECTION ===== */
        .king-panel {
            display: grid;
            grid-template-columns: 1fr;
            background: white;
            border-radius: 60px 20px 60px 20px;
            overflow: hidden;
            box-shadow: var(--shadow-strong);
            border: 2px solid var(--gold-leaf);
            margin: 2rem 0;
        }

        @media (min-width: 768px) {
            .king-panel {
                grid-template-columns: 0.8fr 1.2fr;
                border-radius: 120px 30px 120px 30px;
                margin: 3rem 0;
            }
        }

        .king-left {
            background: linear-gradient(145deg, #165a5a, #0a4242);
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 2rem;
        }

        @media (min-width: 768px) {
            .king-left {
                padding: 3rem;
            }
        }

        .king-photo {
            width: 100%;
            max-width: 300px;
            height: auto;
            border-radius: 50%;
            border: 5px solid var(--gold-leaf);
            box-shadow: 0 10px 20px rgba(0,0,0,0.3);
            object-fit: cover;
            aspect-ratio: 1/1;
        }

        .king-right {
            padding: 2rem 1.5rem;
            background: var(--cream);
        }

        @media (min-width: 768px) {
            .king-right {
                padding: 3rem 3rem 3rem 2rem;
            }
        }

        .king-name {
            font-size: 2.2rem;
            font-weight: 800;
            color: var(--sapphire);
            line-height: 1.1;
        }

        @media (min-width: 480px) {
            .king-name {
                font-size: 2.8rem;
            }
        }

        @media (min-width: 768px) {
            .king-name {
                font-size: 3.5rem;
            }
        }

        .king-badge {
            display: inline-block;
            background: var(--ruby);
            color: white;
            padding: 0.2rem 1.2rem;
            border-radius: 40px;
            font-size: 0.9rem;
            margin: 0.8rem 0 1rem;
            font-weight: 600;
        }

        @media (min-width: 768px) {
            .king-badge {
                padding: 0.3rem 2rem;
                font-size: 1.2rem;
                margin: 1rem 0 1.2rem;
            }
        }

        .king-right p {
            font-size: 1rem;
            color: #1e3e3e;
            margin-bottom: 1.5rem;
            line-height: 1.6;
        }

        @media (min-width: 768px) {
            .king-right p {
                font-size: 1.2rem;
                margin-bottom: 2rem;
            }
        }

        .btn-king {
            background: transparent;
            border: 2px solid var(--ruby);
            padding: 0.7rem 1.5rem;
            font-size: 1rem;
            border-radius: 50px;
            font-weight: 700;
            color: var(--ruby);
            cursor: pointer;
            transition: 0.2s;
            width: 100%;
            max-width: 280px;
        }

        @media (min-width: 480px) {
            .btn-king {
                width: auto;
                padding: 0.8rem 2rem;
                font-size: 1.1rem;
            }
        }

        @media (min-width: 768px) {
            .btn-king {
                border-width: 3px;
                padding: 0.9rem 2.2rem;
                font-size: 1.2rem;
            }
        }

        .btn-king:hover {
            background: var(--ruby);
            color: white;
        }

        /* ===== HISTORY MOSAIC ===== */
        .history-mosaic {
            display: grid;
            grid-template-columns: 1fr;
            gap: 1.2rem;
            margin: 1.5rem 0 2rem;
        }

        @media (min-width: 480px) {
            .history-mosaic {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (min-width: 768px) {
            .history-mosaic {
                grid-template-columns: repeat(3, 1fr);
                gap: 1.8rem;
                margin: 2rem 0 3rem;
            }
        }

        .history-card {
            background: white;
            border-radius: 40px 10px 40px 10px;
            padding: 1.8rem 1.2rem;
            box-shadow: 0 15px 25px -12px #266060;
            border: 1px solid #efcfa7;
            transition: 0.3s;
        }

        @media (min-width: 768px) {
            .history-card {
                border-radius: 60px 15px 60px 15px;
                padding: 2.5rem 1.8rem;
            }
        }

        .history-card:hover {
            transform: translateY(-8px);
        }

        @media (min-width: 768px) {
            .history-card:hover {
                transform: translateY(-15px);
            }
        }

        .history-icon {
            font-size: 2.5rem;
            color: var(--amber);
            margin-bottom: 0.8rem;
        }

        @media (min-width: 768px) {
            .history-icon {
                font-size: 3.5rem;
            }
        }

        .history-card h3 {
            font-size: 1.6rem;
            color: var(--sapphire);
            font-weight: 800;
            margin-bottom: 0.5rem;
        }

        @media (min-width: 768px) {
            .history-card h3 {
                font-size: 2.2rem;
            }
        }

        .history-card p {
            font-size: 0.95rem;
            line-height: 1.5;
        }

        /* ===== NEWS GRID ===== */
        .news-grid-dynamic {
            display: grid;
            grid-template-columns: 1fr;
            gap: 1.5rem;
            margin: 2rem 0;
        }

        @media (min-width: 480px) {
            .news-grid-dynamic {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (min-width: 768px) {
            .news-grid-dynamic {
                grid-template-columns: repeat(3, 1fr);
                gap: 2rem;
                margin: 3rem 0;
            }
        }

        .news-super {
            background: #ffffff;
            border-radius: 35px 8px 35px 8px;
            overflow: hidden;
            box-shadow: 0 20px 25px -15px #0f5353;
            border: 1px solid #f0cba2;
            transition: 0.25s;
            cursor: pointer;
        }

        @media (min-width: 768px) {
            .news-super {
                border-radius: 45px 10px 45px 10px;
            }
        }

        .news-super:hover {
            transform: translateY(-5px);
        }

        @media (min-width: 768px) {
            .news-super:hover {
                transform: translateY(-10px);
            }
        }

        .news-img-super {
            height: 160px;
            background-size: cover;
            background-position: center;
            position: relative;
        }

        @media (min-width: 768px) {
            .news-img-super {
                height: 200px;
            }
        }

        .news-category {
            position: absolute;
            bottom: 10px;
            right: 10px;
            background: var(--ruby);
            color: white;
            padding: 0.2rem 1rem;
            border-radius: 40px;
            font-weight: 600;
            font-size: 0.8rem;
        }

        @media (min-width: 768px) {
            .news-category {
                bottom: 15px;
                right: 15px;
                padding: 0.3rem 1.5rem;
                font-size: 0.9rem;
            }
        }

        .news-content-super {
            padding: 1.2rem 1.2rem 1.5rem;
        }

        @media (min-width: 768px) {
            .news-content-super {
                padding: 1.8rem;
            }
        }

        .news-content-super h3 {
            font-size: 1.4rem;
            color: var(--sapphire);
            margin-bottom: 0.5rem;
        }

        @media (min-width: 768px) {
            .news-content-super h3 {
                font-size: 1.7rem;
            }
        }

        .news-content-super p {
            font-size: 0.9rem;
            line-height: 1.5;
        }

        /* ===== EVENTS TIMELINE ===== */
        .event-timeline {
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }

        .event-item-distinct {
            background: linear-gradient(95deg, #fef5e6, white);
            border-radius: 60px 15px 60px 15px;
            padding: 1.2rem 1.5rem;
            display: flex;
            flex-direction: column;
            align-items: flex-start;
            gap: 0.8rem;
            border-left: 6px solid var(--amber);
            box-shadow: 0 8px 15px -10px #174e4e;
            transition: 0.2s;
            cursor: pointer;
        }

        @media (min-width: 480px) {
            .event-item-distinct {
                flex-direction: row;
                align-items: center;
                padding: 1.5rem 2rem;
            }
        }

        @media (min-width: 768px) {
            .event-item-distinct {
                border-radius: 100px 20px 100px 20px;
                padding: 1.8rem 2.5rem;
                gap: 2.5rem;
                border-left-width: 10px;
            }
        }

        .event-item-distinct:hover {
            border-left-color: var(--ruby);
            transform: translateX(5px);
        }

        @media (min-width: 768px) {
            .event-item-distinct:hover {
                transform: translateX(12px);
            }
        }

        .event-year {
            font-size: 1.8rem;
            font-weight: 800;
            color: var(--ruby);
            min-width: auto;
        }

        @media (min-width: 480px) {
            .event-year {
                font-size: 2rem;
                min-width: 90px;
            }
        }

        @media (min-width: 768px) {
            .event-year {
                font-size: 2.5rem;
                min-width: 110px;
            }
        }

        .event-item-distinct div h3 {
            font-size: 1.3rem !important;
            color: var(--sapphire) !important;
            margin-bottom: 0.3rem;
        }

        @media (min-width: 480px) {
            .event-item-distinct div h3 {
                font-size: 1.5rem !important;
            }
        }

        @media (min-width: 768px) {
            .event-item-distinct div h3 {
                font-size: 2rem !important;
            }
        }

        .event-item-distinct div p {
            font-size: 0.9rem;
        }

        /* ===== HERITAGE SHOWCASE ===== */
        .heritage-showcase {
            display: grid;
            grid-template-columns: 1fr;
            gap: 1.2rem;
            margin: 2rem 0;
        }

        @media (min-width: 480px) {
            .heritage-showcase {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (min-width: 768px) {
            .heritage-showcase {
                grid-template-columns: repeat(3, 1fr);
                gap: 2rem;
                margin: 2.5rem 0;
            }
        }

        .heritage-piece {
            background: #fcf3e4;
            border-radius: 50px 10px 50px 10px;
            padding: 1.5rem 1rem;
            text-align: center;
            border: 2px dashed var(--gold-leaf);
            transition: 0.3s;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
        }

        @media (min-width: 768px) {
            .heritage-piece {
                border-radius: 80px 15px 80px 15px;
                padding: 2rem 1.5rem;
            }
        }

        .heritage-piece:hover {
            background: var(--sapphire);
            color: white;
        }

        .heritage-image {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            object-fit: cover;
            margin-bottom: 1rem;
            border: 3px solid var(--ruby);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }

        @media (min-width: 768px) {
            .heritage-image {
                width: 150px;
                height: 150px;
            }
        }

        .heritage-piece i {
            font-size: 2.8rem;
            color: var(--ruby);
            margin-bottom: 0.8rem;
        }

        @media (min-width: 768px) {
            .heritage-piece i {
                font-size: 4rem;
            }
        }

        .heritage-piece h3 {
            font-size: 1.3rem;
        }

        .heritage-piece:hover i {
            color: var(--amber);
        }

        /* ===== LINEAGE BANNER ===== */
        .lineage-banner-modern {
            background: linear-gradient(105deg, #c44536, #ed9a4a);
            border-radius: 60px;
            padding: 1.2rem 1rem;
            text-align: center;
            font-size: 1.1rem;
            font-weight: 700;
            color: #fff7e3;
            margin: 2rem 0 1.5rem;
            box-shadow: 0 20px 25px -12px #973f2e;
            border: 2px solid white;
            line-height: 1.4;
        }

        @media (min-width: 480px) {
            .lineage-banner-modern {
                font-size: 1.3rem;
                padding: 1.3rem 1.5rem;
            }
        }

        @media (min-width: 768px) {
            .lineage-banner-modern {
                border-radius: 120px;
                padding: 1.5rem 2rem;
                font-size: 1.8rem;
                margin: 3rem 0 2rem;
                border-width: 3px;
            }
        }

        /* ===== FOOTER ===== */
        .footer-attractive {
            background: #0f4c5c;
            color: #f0e5d5;
            padding: 2rem 1.5rem;
            border-top: 8px solid var(--amber);
            margin-top: 3rem;
        }

        @media (min-width: 768px) {
            .footer-attractive {
                padding: 3rem 2rem;
                border-top-width: 12px;
                margin-top: 4rem;
            }
        }

        .footer-flex-attractive {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 1.2rem;
            text-align: center;
        }

        @media (min-width: 480px) {
            .footer-flex-attractive {
                flex-direction: row;
                justify-content: space-between;
                text-align: left;
            }
        }

        .footer-flex-attractive div:first-child {
            font-size: 1.8rem !important;
            font-weight: 800;
        }

        @media (min-width: 768px) {
            .footer-flex-attractive div:first-child {
                font-size: 2.2rem !important;
            }
        }

        .social-icons {
            display: flex;
            gap: 1rem;
        }

        .social-icons i {
            font-size: 1.6rem;
            margin: 0;
            color: #fad2a6;
            transition: 0.15s;
        }

        @media (min-width: 768px) {
            .social-icons i {
                font-size: 2rem;
            }
        }

        .social-icons i:hover {
            color: var(--ruby);
            transform: scale(1.2);
        }

        /* ===== BACK BUTTON ===== */
        .back-button {
            display: inline-block;
            background: var(--sapphire);
            color: white;
            padding: 0.8rem 2rem;
            border-radius: 40px;
            text-decoration: none;
            font-weight: 600;
            margin: 1rem 0;
            transition: 0.15s;
        }

        .back-button:hover {
            background: var(--ruby);
            transform: scale(1.05);
        }

        .back-button i {
            margin-right: 0.5rem;
        }
    </style>
</head>
<body>