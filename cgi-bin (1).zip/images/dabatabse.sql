-- database.sql - Run this in phpMyAdmin
CREATE TABLE IF NOT EXISTS slides (
    id INT AUTO_INCREMENT PRIMARY KEY,
    headline VARCHAR(255) NOT NULL,
    tagline VARCHAR(255) NOT NULL,
    description TEXT,
    image_path VARCHAR(500) NOT NULL,
    slide_order INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS news (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    category VARCHAR(100),
    description TEXT,
    image_path VARCHAR(500),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    event_name VARCHAR(255) NOT NULL,
    event_year VARCHAR(20),
    description TEXT,
    extra_info VARCHAR(500),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS lineage_banner (
    id INT AUTO_INCREMENT PRIMARY KEY,
    banner_text TEXT NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Insert default data
INSERT INTO lineage_banner (banner_text) VALUES 
('Ibrahim · Isaag · Yaqut · King Mohammed · King of Isaag — preserved lineage');

INSERT INTO slides (headline, tagline, description, image_path, slide_order) VALUES
('Isaaq Kingdom', 'Boqortooyada Isaaq · المملكة الإسحاقية', 'Tolje''lo dynasty · eight kings, one legacy', 'images/slide1.jpg', 1),
('The Royal Chronicle', 'King Harun to King Dhuuh Baraar', 'From the first Tolje''lo ruler to the last sovereign', 'images/slide2.jpg', 2),
('Land of Maydh & Ogo', 'Cradle of the Isaaq clans', 'Where Sheikh Ishaaq settled', 'images/slide3.jpg', 3);

INSERT INTO news (title, category, description, image_path) VALUES
('Tradition & law', 'Royal Courts', 'Parallels with Zulu kingdom''s legal recognition.', 'images/news1.jpg'),
('King Dhuuh Baraar honoured', 'Honour', 'Somali & Nigerian Itsekiri representatives unite.', 'images/news2.jpg'),
('Delegation in London', 'International', 'Talks for artefact return.', 'images/news3.jpg');

INSERT INTO events (event_name, event_year, description) VALUES
('Booqor: Tolje''lo Legacy', '2026', 'Hargeisa premiere with royal elders.'),
('Battle of Maydh Commemoration', '2025', 'Gabay poetry remembrance.'),
('Isaaq Guurti Council', '2025', 'Annual festival & xeer reaffirmation.');